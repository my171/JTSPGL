-- MySQL dump 10.13  Distrib 8.4.5, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mysqldemo
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory` (
  `warehouse_id` varchar(10) NOT NULL,
  `product_id` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `quantity` int NOT NULL,
  PRIMARY KEY (`warehouse_id`,`product_id`,`date`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouse` (`warehouse_id`),
  CONSTRAINT `inventory_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES ('WH002','P10004','2023-01-31',450),('WH002','P10004','2023-06-30',280),('WH002','P10004','2023-12-31',850),('WH002','P10012','2023-01-31',780),('WH002','P10012','2023-06-30',450),('WH002','P10012','2023-12-31',980),('WH002','P10022','2023-01-31',560),('WH002','P10022','2023-06-30',310),('WH002','P10022','2023-12-31',720),('WH004','P10015','2023-01-31',2100),('WH004','P10015','2023-06-30',1850),('WH004','P10015','2023-12-31',2850),('WH004','P10026','2023-01-31',1850),('WH004','P10026','2023-06-30',1620),('WH004','P10026','2023-12-31',2250),('WH005','P10014','2023-01-31',420),('WH005','P10014','2023-06-30',1250),('WH005','P10014','2023-12-31',280),('WH005','P10027','2023-01-31',760),('WH005','P10027','2023-06-30',980),('WH005','P10027','2023-12-31',350);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `product_id` varchar(20) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES ('P10001','华为Mate60 Pro',6999.00),('P10002','iPhone 15',5999.00),('P10003','小米平板6',2299.00),('P10004','索尼4K电视',8999.00),('P10005','戴尔笔记本电脑',5499.00),('P10006','大疆无人机',7999.00),('P10007','佳能单反相机',9880.00),('P10008','Bose降噪耳机',2499.00),('P10010','Apple Watch',3199.00),('P10011','九阳破壁机',1299.00),('P10012','戴森吸尘器',3990.00),('P10013','科沃斯扫地机',3599.00),('P10014','美的空调',4299.00),('P10015','苏泊尔电饭煲',899.00),('P10016','飞利浦剃须刀',1599.00),('P10018','海尔冰箱',6599.00),('P10019','海信洗衣机',3899.00),('P10020','荣耀智能手环',399.00),('P10021','联想游戏本',7999.00),('P10022','三星曲面显示器',3299.00),('P10024','极米投影仪',4599.00),('P10025','韶音运动耳机',1298.00),('P10026','北通游戏手柄',299.00),('P10027','罗技机械键盘',899.00),('P10028','西部数据移动硬盘',699.00),('P10029','安克充电宝',399.00),('P10030','小米空气净化器',1499.00);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `store_id` varchar(10) NOT NULL,
  `product_id` varchar(10) NOT NULL,
  `month` date NOT NULL,
  `monthly_sales` int NOT NULL,
  PRIMARY KEY (`store_id`,`product_id`,`month`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`),
  CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES ('ST101','P10001','2023-01-01',85),('ST101','P10001','2023-06-01',215),('ST101','P10001','2023-12-01',185),('ST101','P10004','2023-01-01',42),('ST101','P10004','2023-06-01',128),('ST101','P10004','2023-12-01',92),('ST101','P10018','2023-01-01',38),('ST101','P10018','2023-06-01',95),('ST101','P10018','2023-12-01',82),('ST103','P10008','2023-01-01',78),('ST103','P10008','2023-06-01',168),('ST103','P10008','2023-12-01',142),('ST103','P10019','2023-01-01',52),('ST103','P10019','2023-06-01',125),('ST103','P10019','2023-12-01',98),('ST103','P10030','2023-01-01',95),('ST103','P10030','2023-06-01',198),('ST103','P10030','2023-12-01',165),('ST104','P10015','2023-01-01',185),('ST104','P10015','2023-06-01',285),('ST104','P10015','2023-12-01',195),('ST104','P10024','2023-01-01',62),('ST104','P10024','2023-06-01',145),('ST104','P10024','2023-12-01',105),('ST105','P10014','2023-01-01',28),('ST105','P10014','2023-06-01',125),('ST105','P10014','2023-12-01',85),('ST105','P10026','2023-01-01',76),('ST105','P10026','2023-06-01',198),('ST105','P10026','2023-12-01',135),('ST106','P10006','2023-01-01',32),('ST106','P10006','2023-06-01',78),('ST106','P10006','2023-12-01',65),('ST106','P10011','2023-01-01',85),('ST106','P10011','2023-06-01',165),('ST106','P10011','2023-12-01',125),('ST106','P10021','2023-01-01',45),('ST106','P10021','2023-06-01',125),('ST106','P10021','2023-12-01',98),('ST107','P10007','2023-01-01',28),('ST107','P10007','2023-06-01',68),('ST107','P10007','2023-12-01',45),('ST107','P10016','2023-01-01',75),('ST107','P10016','2023-06-01',185),('ST107','P10016','2023-12-01',125),('ST107','P10025','2023-01-01',92),('ST107','P10025','2023-06-01',165),('ST107','P10025','2023-12-01',142),('ST109','P10013','2023-01-01',52),('ST109','P10013','2023-06-01',125),('ST109','P10013','2023-12-01',98),('ST109','P10020','2023-01-01',185),('ST109','P10020','2023-06-01',285),('ST109','P10020','2023-12-01',225),('ST109','P10028','2023-01-01',95),('ST109','P10028','2023-06-01',195),('ST109','P10028','2023-12-01',165),('ST110','P10005','2023-01-01',45),('ST110','P10005','2023-06-01',95),('ST110','P10005','2023-12-01',85),('ST110','P10014','2023-01-01',92),('ST110','P10014','2023-06-01',185),('ST110','P10014','2023-12-01',142),('ST110','P10029','2023-06-01',165),('ST110','P10029','2023-12-01',125);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store`
--

DROP TABLE IF EXISTS `store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store` (
  `store_id` varchar(10) NOT NULL,
  `store_name` varchar(50) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store`
--

LOCK TABLES `store` WRITE;
/*!40000 ALTER TABLE `store` DISABLE KEYS */;
INSERT INTO `store` VALUES ('ST101','北京王府井旗舰店','北京市东城区王府井大街218号'),('ST103','广州天河城店','广州市天河区天河路208号'),('ST104','深圳万象城店','深圳市罗湖区宝安南路1881号'),('ST105','成都春熙路店','成都市锦江区红星路三段1号'),('ST106','重庆解放碑店','重庆市渝中区民权路28号'),('ST107','武汉武商广场店','武汉市江汉区解放大道688号'),('ST109','杭州西湖店','杭州市上城区延安路292号'),('ST110','西安钟楼店','西安市碑林区东大街8号');
/*!40000 ALTER TABLE `store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supply`
--

DROP TABLE IF EXISTS `supply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supply` (
  `warehouse_id` varchar(10) NOT NULL,
  `store_id` varchar(10) NOT NULL,
  `product_id` varchar(10) NOT NULL,
  `month` date NOT NULL,
  `monthly_supply` int NOT NULL,
  PRIMARY KEY (`warehouse_id`,`store_id`,`product_id`,`month`),
  KEY `store_id` (`store_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `supply_ibfk_1` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouse` (`warehouse_id`),
  CONSTRAINT `supply_ibfk_2` FOREIGN KEY (`store_id`) REFERENCES `store` (`store_id`),
  CONSTRAINT `supply_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supply`
--

LOCK TABLES `supply` WRITE;
/*!40000 ALTER TABLE `supply` DISABLE KEYS */;
INSERT INTO `supply` VALUES ('WH002','ST109','P10013','2023-01-01',55),('WH002','ST109','P10013','2023-06-01',130),('WH002','ST109','P10013','2023-12-01',105),('WH002','ST109','P10020','2023-01-01',190),('WH002','ST109','P10020','2023-06-01',290),('WH002','ST109','P10020','2023-12-01',230),('WH002','ST109','P10028','2023-01-01',100),('WH002','ST109','P10028','2023-06-01',200),('WH002','ST109','P10028','2023-12-01',170),('WH004','ST105','P10014','2023-01-01',30),('WH004','ST105','P10014','2023-06-01',130),('WH004','ST105','P10014','2023-12-01',90),('WH004','ST105','P10026','2023-01-01',80),('WH004','ST105','P10026','2023-12-01',140),('WH004','ST106','P10006','2023-01-01',35),('WH004','ST106','P10006','2023-06-01',85),('WH004','ST106','P10006','2023-12-01',70),('WH004','ST106','P10011','2023-01-01',90),('WH004','ST106','P10011','2023-06-01',170),('WH004','ST106','P10011','2023-12-01',130),('WH004','ST106','P10021','2023-01-01',50),('WH004','ST106','P10021','2023-06-01',130),('WH004','ST106','P10021','2023-12-01',105),('WH005','ST110','P10005','2023-01-01',50),('WH005','ST110','P10005','2023-06-01',100),('WH005','ST110','P10005','2023-12-01',90),('WH005','ST110','P10014','2023-01-01',95),('WH005','ST110','P10014','2023-06-01',190),('WH005','ST110','P10014','2023-12-01',150),('WH005','ST110','P10029','2023-01-01',80),('WH005','ST110','P10029','2023-06-01',170),('WH005','ST110','P10029','2023-12-01',130);
/*!40000 ALTER TABLE `supply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `warehouse`
--

DROP TABLE IF EXISTS `warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `warehouse` (
  `warehouse_id` varchar(10) NOT NULL,
  `warehouse_name` varchar(50) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`warehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warehouse`
--

LOCK TABLES `warehouse` WRITE;
/*!40000 ALTER TABLE `warehouse` DISABLE KEYS */;
INSERT INTO `warehouse` VALUES ('WH002','华东智能仓','上海市浦东新区临港物流基地'),('WH004','西南分拨中心','成都市双流区空港物流园'),('WH005','东北冷链仓','沈阳市浑南区冷链物流基地');
/*!40000 ALTER TABLE `warehouse` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-10 14:38:38
